# StuTech — full-stack learning resources website

A responsive Next.js website with Supabase authentication/database/private file storage, an admin upload panel, searchable resource library, and optional Razorpay checkout for paid resources.

## Requirements
- Node.js 20.9 or newer
- A Supabase project
- Razorpay account for payments (start in test mode)

## 1. Install and run

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000. Fill `.env.local` with your Supabase project URL and anon key. Never commit `.env.local` or expose `SUPABASE_SERVICE_ROLE_KEY` / `RAZORPAY_KEY_SECRET` in client-side code.

On Windows PowerShell, copy the env template with:

```powershell
Copy-Item .env.example .env.local
```

## 2. Set up Supabase
1. Create a project at https://supabase.com.
2. In Project Settings → API, copy the Project URL and anon/public key into `.env.local`.
3. Open SQL Editor and run all of `supabase-schema.sql`.
4. In Storage, create a **private** bucket named `resources`. Do not make it public.
5. In Authentication → URL Configuration, set the local Site URL to `http://localhost:3000`. Add your deployed website URL before production.
6. Register a user at `/signup`. Confirm their email if confirmation is enabled.
7. In SQL Editor, promote your own account to admin using the email you registered with:

```sql
update public.profiles p
set role = 'admin'
from auth.users u
where p.id = u.id and u.email = 'YOUR_EMAIL@example.com';
```

Only trusted site owners should receive the admin role. Never add a public admin signup option.

## 3. Configure payments (optional)
1. Create a Razorpay account and use **test keys** first.
2. Put the Key ID in both `RAZORPAY_KEY_ID` and `NEXT_PUBLIC_RAZORPAY_KEY_ID`; put the secret in `RAZORPAY_KEY_SECRET` in `.env.local`.
3. Restart `npm run dev` after changing environment variables.
4. Test a paid resource with Razorpay's test checkout. Before launch, configure and test Razorpay webhooks, refunds, reconciliation, order/resource ownership checks, and your applicable tax/consumer policies. Do not switch to live keys until the account and site are ready.

## 4. Upload and download resources
- Log in with the admin account, then open `/admin`.
- Upload PDF, PPT/PPTX, DOCX, XLSX, ZIP, text, JPG or PNG files (maximum 30 MB).
- Free resources can be downloaded by signed-in students. Paid resources use Razorpay checkout and require a recorded purchase to download.
- Public resource listing uses only published entries; file storage remains private and downloads use short-lived signed URLs.

## 5. Deploy
Deploy to Vercel or another Node-compatible host. Add all `.env.local` values as production environment variables. Set `NEXT_PUBLIC_SITE_URL` to the final HTTPS URL and update Supabase Auth URL configuration. Run `npm run build` before deploying.

## Notes / production hardening
- This is a functional starter project, not a substitute for a production security review.
- The service-role key bypasses Supabase RLS; keep it server-only.
- For a production payment system, verify order metadata and amount against Razorpay's server API and use signed webhooks as the durable source of payment status. Add rate limiting, audit logs, refund handling, and monitoring before accepting real money.
- Configure email templates, privacy policy, terms, support contact, and accessibility checks for your audience.
