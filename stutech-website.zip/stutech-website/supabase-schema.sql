-- Run in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  subject text,
  file_type text default 'PDF',
  price_paise integer not null default 0 check (price_paise >= 0),
  is_free boolean not null default true,
  file_path text,
  published boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint free_resources_have_zero_price check (not is_free or price_paise = 0)
);
create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  resource_id uuid not null references public.resources(id) on delete cascade,
  razorpay_order_id text not null,
  razorpay_payment_id text not null unique,
  status text not null default 'paid' check (status in ('paid','refunded','failed')),
  created_at timestamptz not null default now(),
  unique(user_id, resource_id, razorpay_payment_id)
);
-- Create a profile for every new signup. Users cannot grant themselves admin.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data ->> 'full_name'); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.resources enable row level security;
alter table public.purchases enable row level security;
create policy "Users can read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users can update own profile name" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id and role = 'student');
create policy "Published resources are visible" on public.resources for select to anon, authenticated using (published = true);
create policy "Users can read own purchases" on public.purchases for select to authenticated using (auth.uid() = user_id);
-- Writes to resources and purchases are performed server-side with service-role key.
-- Create a private Storage bucket named "resources" in Supabase Storage. Do not make it public.
